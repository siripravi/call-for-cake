<?php
namespace Rtwpvgp\Controllers\Admin\Meta;

class MetaOptions {  
    function __construct() {
        // tab option filter  
    }    
}