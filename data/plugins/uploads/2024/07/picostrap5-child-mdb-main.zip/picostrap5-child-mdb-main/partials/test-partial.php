<div class="alert alert-warning">

<h1>Hello</h1>

<h2>This content is in the partials/test-partial.php file inside your Child Theme folder.</h2>
</div>
