 
        _               _                  _____        _     _ _     _   _   _                         
       (_)             | |                | ____|      | |   (_) |   | | | | | |                        
  _ __  _  ___ ___  ___| |_ _ __ __ _ _ __| |__     ___| |__  _| | __| | | |_| |__   ___ _ __ ___   ___ 
 | '_ \| |/ __/ _ \/ __| __| '__/ _` | '_ \___ \   / __| '_ \| | |/ _` | | __| '_ \ / _ \ '_ ` _ \ / _ \
 | |_) | | (_| (_) \__ \ |_| | | (_| | |_) |__) | | (__| | | | | | (_| | | |_| | | |  __/ | | | | |  __/
 | .__/|_|\___\___/|___/\__|_|  \__,_| .__/____/   \___|_| |_|_|_|\__,_|  \__|_| |_|\___|_| |_| |_|\___|
 | |                                 | |                                                                
 |_|                                 |_|                                                                

                                                       
*************************************** WELCOME TO PICOSTRAP ***************************************

********************* THE BEST WAY TO EXPERIENCE SASS, BOOTSTRAP AND WORDPRESS *********************


FONTS IN PICOSTRAP 
 
Picostrap comes with easy, built-in Google Fonts integration.

You can browse Google Fonts from the Customizer and set custom fonts for headers or all body text.

Upon selecting a font, basically two things happen under the hood:

-  Corresponding Font fields in the Customizer are populated with the chosen value. This directly translates to setting  Bootstrap SCSS variables

- A Font Loading Code Snippet is created and added to the Header automatically. This is stored in a field that can be actually seen and edited in the Customizer.

PRIVACY / GDPS CONCERNS? IF YOU DONT WANT TO LOAD FONTS FROM THE GOOGLE SERVERS, just tick  a box

The Font Loading can be easily configured to use a GDPR - compliant CDN clone

DO YOU NEED TO LOAD MULTIPLE FONT WEIGHTS?

The Font Loading can also be manually refined, for example to be able to load multiple font weights.

GET TO KNOW MORE 

Please watch the video documentation about Fonts:  https://youtu.be/dmsUpFJwDW8?t=199



ADDING CUSTOM (NON-GOOGLE), LOCALLY-STORED FONTS

Please refer to this article:
https://docs.livecanvas.com/how-to-use-custom-fonts/