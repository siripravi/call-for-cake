//how to use this file

// 1. copy a config from the plugin folder: 
//
//livecanvas/editor/configs/bs
//
// and paste it below
//
// 2. rename this file eliminating "_OPTIONAL" to go live

